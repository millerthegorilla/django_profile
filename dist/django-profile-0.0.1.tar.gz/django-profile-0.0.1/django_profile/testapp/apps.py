from django.apps import AppConfig


class TestAppConfig(AppConfig):
    name = "django_profile.tests.testapp.testapp"
    verbose_name = "TestAppConfig"
